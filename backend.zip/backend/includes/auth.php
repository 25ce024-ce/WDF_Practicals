<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$timeoutSeconds = 1800;
if (isset($_SESSION['last_activity']) && time() - (int)$_SESSION['last_activity'] > $timeoutSeconds) { $_SESSION = []; session_destroy(); header('Location: ../login.php?timeout=1'); exit; }
if (isset($_SESSION['user_id'])) $_SESSION['last_activity'] = time();
function require_login(): void { if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; } }
function require_admin(): void { require_login(); if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit('403 Forbidden: administrator access required.'); } }
