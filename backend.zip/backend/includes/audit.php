<?php
function audit_log(mysqli $conn, ?int $userId, string $action, string $details = ''): void { $stmt=$conn->prepare('INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)'); $ip=$_SERVER['REMOTE_ADDR'] ?? 'local'; $stmt->bind_param('isss',$userId,$action,$details,$ip); $stmt->execute(); $stmt->close(); }
