<?php
declare(strict_types=1);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed.'); }
$name=trim((string)($_POST['fullName'] ?? $_POST['name'] ?? '')); $email=filter_var(trim((string)($_POST['email'] ?? '')), FILTER_VALIDATE_EMAIL); $message=trim((string)($_POST['message'] ?? ''));
$errors=[]; if (mb_strlen($name)<3 || mb_strlen($name)>60) $errors[]='Name must be 3–60 characters.'; if (!$email) $errors[]='A valid email is required.'; if (($_POST['form_type'] ?? '')==='contact' && $message==='') $errors[]='Message is required.';
if ($errors) { http_response_code(422); echo '<h1>Please correct the form</h1><ul>'; foreach($errors as $e) echo '<li>'.htmlspecialchars($e,ENT_QUOTES,'UTF-8').'</li>'; echo '</ul><p><a href="../contact.html">Return to form</a></p>'; exit; }
$storage=__DIR__.'/storage'; if (!is_dir($storage)) mkdir($storage,0750,true); $file=$storage.'/contact-submissions.csv'; $fh=fopen($file,'ab'); if ($fh) { if (flock($fh,LOCK_EX)) { fputcsv($fh,[date(DATE_ATOM),$name,$email,$message]); flock($fh,LOCK_UN); } fclose($fh); }
$record=['created_at'=>date(DATE_ATOM),'name'=>$name,'email'=>$email,'message'=>$message]; $jsonFile=$storage.'/contact-submissions.json'; $records=[]; if (is_file($jsonFile)) { $decoded=json_decode((string)file_get_contents($jsonFile),true); if(is_array($decoded)) $records=$decoded; } $records[]=$record; file_put_contents($jsonFile,json_encode($records,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX);
echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>Submission received</title><h1>Submission received</h1><p>Your form data passed server-side validation and was saved to local CSV/JSON files.</p><a href="../index.html">Return home</a></html>';
