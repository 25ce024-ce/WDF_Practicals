<?php require __DIR__ . '/config.php';
require __DIR__ . '/includes/auth.php';
require __DIR__ . '/includes/audit.php';
require_admin();
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = (int)($_POST['id'] ?? 0);
    if ($action === 'delete' && $id > 0) {
        $s = $conn->prepare('DELETE FROM students WHERE id=?');
        $s->bind_param('i', $id);
        $s->execute();
        $s->close();
        audit_log($conn, (int)$_SESSION['user_id'], 'student.delete', 'student_id=' . $id);
        $notice = 'Student deleted.';
    } elseif ($action === 'save') {
        $name = trim((string)($_POST['name'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $course = trim((string)($_POST['course'] ?? ''));
        $year = (int)($_POST['year'] ?? 1);
        if ($name !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) && in_array($course, ['B.Tech', 'BCA', 'MCA'], true) && $year >= 1 && $year <= 4) {
            if ($id > 0) {
                $s = $conn->prepare('UPDATE students SET name=?,email=?,course=?,year=? WHERE id=?');
                $s->bind_param('sssii', $name, $email, $course, $year, $id);
                $s->execute();
                $s->close();
                audit_log($conn, (int)$_SESSION['user_id'], 'student.update', 'student_id=' . $id);
                $notice = 'Student updated.';
            } else {
                $s = $conn->prepare('INSERT INTO students(name,email,course,year) VALUES(?,?,?,?)');
                $s->bind_param('sssi', $name, $email, $course, $year);
                $s->execute();
                $id = $s->insert_id;
                $s->close();
                audit_log($conn, (int)$_SESSION['user_id'], 'student.create', 'student_id=' . $id);
                $notice = 'Student added.';
            }
        } else $notice = 'Please provide valid student fields.';
    }
}
$q = trim((string)($_GET['q'] ?? ''));
$like = '%' . $q . '%';
$stmt = $conn->prepare('SELECT id,name,email,course,year FROM students WHERE name LIKE ? OR email LIKE ? OR course LIKE ? ORDER BY id DESC LIMIT 100');
$stmt->bind_param('sss', $like, $like, $like);
$stmt->execute();
$rows = $stmt->get_result(); ?>
<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Student Management</title>
<link rel="stylesheet" href="../assets/css/style.css">
<main class="container page">
    <h1>Student Management</h1>
    <p><?= htmlspecialchars($notice, ENT_QUOTES, 'UTF-8') ?></p>
    <form method="get"><label for="q">Search by name, email or course</label><input id="q" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>"><button class="button">Search</button></form>
    <h2>Add student</h2>
    <form method="post"><input type="hidden" name="action" value="save"><label>Name <input name="name" required></label><label>Email <input name="email" type="email" required></label><label>Course <select name="course">
                <option>B.Tech</option>
                <option>BCA</option>
                <option>MCA</option>
            </select></label><label>Year <select name="year"><?php for ($i = 1; $i <= 4; $i++) echo "<option>$i</option>"; ?></select></label><button class="button">Add</button></form>
    <h2>Records</h2>
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Course</th>
                    <th>Year</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody><?php while ($r = $rows->fetch_assoc()): ?><tr><?php foreach (['id', 'name', 'email', 'course', 'year'] as $k): ?><td><?= htmlspecialchars((string)$r[$k], ENT_QUOTES, 'UTF-8') ?></td><?php endforeach; ?><td>
                            <form method="post" onsubmit="return confirm('Delete this student?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="button button-outline">Delete</button></form>
                        </td>
                    </tr><?php endwhile; ?></tbody>
        </table>
    </div>
    <p><a href="admin.php">Admin dashboard</a> · <a href="logout.php">Log out</a></p>
</main>

</html>