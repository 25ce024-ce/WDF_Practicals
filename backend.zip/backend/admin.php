<?php require __DIR__ . '/config.php';
require __DIR__ . '/includes/auth.php';
require __DIR__ . '/includes/audit.php';
require_admin();
$counts = [];
foreach (['users', 'students', 'events', 'registrations'] as $table) {
    $counts[$table] = (int)$conn->query("SELECT COUNT(*) AS n FROM `$table`")->fetch_assoc()['n'];
}
$latest = $conn->query('SELECT name,email,created_at FROM users ORDER BY created_at DESC LIMIT 8');
$logs = $conn->query('SELECT a.action,a.details,a.created_at,u.name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 10'); ?>
<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="../assets/css/style.css">
<main class="container page">
    <p class="eyebrow">Administrator</p>
    <h1>StudentHub Admin Dashboard</h1>
    <p>Signed in as <?= htmlspecialchars($_SESSION['name'], ENT_QUOTES, 'UTF-8') ?>.</p>
    <div class="card-grid"><?php foreach ($counts as $label => $count): ?><article class="card">
                <p class="eyebrow"><?= htmlspecialchars(ucfirst($label), ENT_QUOTES, 'UTF-8') ?></p>
                <h2><?= $count ?></h2>
            </article><?php endforeach; ?></div>
    <section class="section">
        <h2>Management</h2>
        <p><a class="button" href="students.php">Manage students</a> <a class="button" href="events.php">Manage events</a></p>
    </section>
    <section class="section">
        <h2>Latest registrations</h2>
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody><?php while ($r = $latest->fetch_assoc()): ?><tr>
                            <td><?= htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($r['email'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($r['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                        </tr><?php endwhile; ?></tbody>
            </table>
        </div>
    </section>
    <section class="section">
        <h2>Recent audit log</h2>
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Action</th>
                        <th>User</th>
                        <th>Details</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody><?php while ($r = $logs->fetch_assoc()): ?><tr>
                            <td><?= htmlspecialchars($r['action'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($r['name'] ?? 'System', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($r['details'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($r['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                        </tr><?php endwhile; ?></tbody>
            </table>
        </div>
    </section>
    <p><a class="button button-outline" href="logout.php">Log out</a></p>
</main>

</html>