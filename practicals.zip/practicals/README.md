# Practical evidence checklist

Use the practical list and this project together when creating the lab record. Capture your own screenshots after running each feature. Do not use placeholder/mock screenshots as evidence of execution.

- P1: requirement analysis, sitemap, wireframe, folder tree, GitHub repository.
- P2: pages and accessibility checks.
- P3: mobile/tablet/desktop responsive views.
- P4: FAQ open/close, theme persistence, menu/banner interactions.
- P5: valid and invalid registration form states.
- P6: JSON loaded, search, filter, sorting and pagination.
- P7: PHP form success and validation failure; CSV/JSON files.
- P8: ER/schema and successful database connection.
- P9: registration success, invalid input and duplicate email.
- P10: login success, failed login, logout, timeout, forbidden role access.
- P11: create/list/search/delete student records.
- P12: create/list/delete event; valid and rejected poster upload.
- P13: API request/response in Network tab; async CRUD.
- P14: admin dashboard statistics, role restriction, audit log.
- P15: integration and deployment checklist, repository link.
