document.addEventListener('DOMContentLoaded',()=>{
 const menuButton=document.querySelector('.menu-toggle'); const nav=document.querySelector('#primary-nav');
 if(menuButton&&nav){menuButton.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));});}
 const savedTheme=localStorage.getItem('studenthub-theme');if(savedTheme==='dark')document.body.classList.add('dark-mode');
 const themeButton=document.createElement('button');themeButton.type='button';themeButton.className='button button-outline';themeButton.textContent=document.body.classList.contains('dark-mode')?'Light mode':'Dark mode';themeButton.style.margin='.5rem';themeButton.addEventListener('click',()=>{document.body.classList.toggle('dark-mode');const dark=document.body.classList.contains('dark-mode');localStorage.setItem('studenthub-theme',dark?'dark':'light');themeButton.textContent=dark?'Light mode':'Dark mode';});
 const header=document.querySelector('.site-header');if(header)header.append(themeButton);
 document.querySelectorAll('.faq-question').forEach(button=>button.addEventListener('click',()=>{const answer=button.closest('.faq-item').querySelector('.faq-answer');const expanded=button.getAttribute('aria-expanded')==='true';button.setAttribute('aria-expanded',String(!expanded));answer.hidden=expanded;}));
 const banner=document.querySelector('#announcement');const dismiss=document.querySelector('#dismiss-announcement');if(dismiss&&banner)dismiss.addEventListener('click',()=>banner.remove());
 const modal=document.querySelector('#site-modal');const close=document.querySelector('#modal-close');if(modal&&close)close.addEventListener('click',()=>modal.hidden=true);
});
