# Integration, testing and local deployment checklist (Practical 15)

- [ ] Import `database/studenthub.sql` without errors.
- [ ] Verify home, about, events, directory, FAQ, contact, feedback, register, login and profile pages load.
- [ ] Check keyboard navigation, labels, alt text and heading order.
- [ ] Check layouts at mobile, tablet and desktop widths.
- [ ] Test theme toggle, FAQ, modal, slider, banner and hamburger menu.
- [ ] Test registration with valid and invalid values; ensure field-level messages are readable.
- [ ] Test JSON loading, search, filters, sort and pagination.
- [ ] Submit valid and invalid data to `backend/process_form.php`.
- [ ] Test registration with a new email and then a duplicate email.
- [ ] Test login success, failed login, logout and session timeout.
- [ ] Test student add/view/edit/delete, search and filter.
- [ ] Test event add/edit/delete and reject invalid/oversized poster uploads.
- [ ] Use browser Network tools to verify JSON API status and response bodies.
- [ ] Confirm a student cannot open the admin dashboard.
- [ ] Confirm administrative actions create audit log entries.
- [ ] Commit changes to Git after each practical and include repository URL in final submission.

## Deployment
Run on local Apache/PHP/MySQL. Set database credentials in `backend/config.php`. Ensure `backend/uploads/event-posters/` is writable. Do not use the seeded demo password on a public server.
