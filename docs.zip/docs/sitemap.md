# StudentHub sitemap

- Home (`index.html`)
- About (`about.html`)
- Events (`events.html`)
- Student Directory (`directory.html`)
- FAQ / Help (`faq.html`)
- Contact (`contact.html`)
- Feedback (`feedback.html`)
- Register (`register.html` and `backend/register.php`)
- Login (`login.html` and `backend/login.php`)
- Student Dashboard (`backend/dashboard.php`)
- Profile (`profile.html`)
- Admin Dashboard (`backend/admin.php`)
- Student Management (`backend/students.php`)
- Event Management (`backend/events.php`)

Visitor flow: Home → Events/Directory/FAQ → Register or Login. Student flow: Login → Student Dashboard → Events/Profile → Logout. Admin flow: Login → Admin Dashboard → Student Management/Event Management → Logout.
