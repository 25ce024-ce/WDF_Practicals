# StudentHub requirements

## Problem statement
Students need one portal to discover campus events, register for an account, view notices and manage their profile. Administrators need to manage student and event records and review basic activity.

## Roles
- Visitor: browse public pages, register and log in.
- Student: access the student dashboard and view event/student information.
- Admin: manage students and events, view dashboard statistics and audit records.

## Functional requirements
1. Provide at least ten linked pages.
2. Use semantic and accessible HTML.
3. Support responsive mobile, tablet and desktop layouts.
4. Add JavaScript interactions and form validation.
5. Fetch and display JSON datasets with search/filter/sort/pagination.
6. Validate and store submitted forms on the server.
7. Persist application data in MySQL using relational keys.
8. Hash passwords, reject duplicate emails and protect role-specific pages.
9. Provide student and event CRUD with safe input handling and poster validation.
10. Expose JSON endpoints for asynchronous CRUD.
11. Record important administrative actions in an audit log.

## Non-functional requirements
- Clear navigation and readable contrast.
- Mobile-first responsive design.
- Reusable CSS and JavaScript.
- Server-side validation in addition to client-side validation.
- Prepared statements for database values.
- Friendly success/error messages; never display raw database credentials.
