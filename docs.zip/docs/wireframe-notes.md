# Low-fidelity wireframe notes

## Shared page shell
[Header: StudentHub logo + responsive navigation]
[Announcement banner, dismissible]
[Main content: page heading, short introduction, cards/forms/data table]
[Footer: About, Contact, Privacy]

## Home
[Welcome hero] [Latest notice card] [Upcoming events cards] [Quick links]

## Registration
[Page heading] [Form fields in a single column on mobile; two columns on desktop] [Inline validation errors] [Submit]

## Events / Directory
[Search box] [Category/filter controls] [Result cards/table] [Previous / page / Next]

## Admin dashboard
[Role-aware sidebar] [Student count card] [Event count card] [Latest registrations table] [Recent audit activity]
